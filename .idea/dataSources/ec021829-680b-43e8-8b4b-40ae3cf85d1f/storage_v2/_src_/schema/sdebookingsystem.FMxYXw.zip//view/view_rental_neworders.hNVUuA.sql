create view view_rental_neworders as
select `sdebookingsystem`.`product_rentals`.`id`                              AS `orderID`,
       `sdebookingsystem`.`users`.`id`                                        AS `userID`,
       `sdebookingsystem`.`users`.`email`                                     AS `email`,
       `sdebookingsystem`.`school_products`.`product_name`                    AS `product_name`,
       `sdebookingsystem`.`product_unit_e`.`unit_number`                      AS `unitID`,
       `sdebookingsystem`.`product_rentals`.`start_date`                      AS `start_date`,
       `sdebookingsystem`.`product_rentals`.`end_date`                        AS `end_date`,
       `sdebookingsystem`.`product_rentals`.`available`                       AS `available`,
       concat_ws('-', `sdebookingsystem`.`location_room`.`room`,
                 concat(`sdebookingsystem`.`product_location_type_svf`.`type`,
                        `sdebookingsystem`.`product_location_type_svf`.`nr`),
                 concat(`sdebookingsystem`.`product_location_type_thp`.`type`,
                        `sdebookingsystem`.`product_location_type_thp`.`nr`)) AS `location`
from ((((((((`sdebookingsystem`.`connection_product_rentals` join `sdebookingsystem`.`product_unit_e` on ((
    `sdebookingsystem`.`connection_product_rentals`.`product_unit_e_id` =
    `sdebookingsystem`.`product_unit_e`.`id`))) join `sdebookingsystem`.`school_products` on ((
    `sdebookingsystem`.`product_unit_e`.`products_id` =
    `sdebookingsystem`.`school_products`.`id`))) join `sdebookingsystem`.`location_room` on ((
    `sdebookingsystem`.`product_unit_e`.`location_room_id` =
    `sdebookingsystem`.`location_room`.`id`))) join `sdebookingsystem`.`product_location_type_svf` on ((
    `sdebookingsystem`.`product_unit_e`.`product_location_type_svf_id` =
    `sdebookingsystem`.`product_location_type_svf`.`id`))) join `sdebookingsystem`.`product_location_type_thp` on ((
    `sdebookingsystem`.`product_unit_e`.`product_location_type_thp_id` =
    `sdebookingsystem`.`product_location_type_thp`.`id`))) join `sdebookingsystem`.`product_rentals` on ((
    `sdebookingsystem`.`connection_product_rentals`.`product_rentals_id` =
    `sdebookingsystem`.`product_rentals`.`id`))) join `sdebookingsystem`.`wish_list` on ((
    `sdebookingsystem`.`product_rentals`.`wish_list_id` = `sdebookingsystem`.`wish_list`.`id`)))
       join `sdebookingsystem`.`users` on ((`sdebookingsystem`.`wish_list`.`user_id` = `sdebookingsystem`.`users`.`id`)))
where (`sdebookingsystem`.`product_rentals`.`available` = 1)
order by `sdebookingsystem`.`product_rentals`.`start_date`,`sdebookingsystem`.`product_rentals`.`id`,`sdebookingsystem`.`school_products`.`product_name`;

